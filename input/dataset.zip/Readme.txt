foregroundset:

nbt1146-S6.txt
This foreground data set is directly adopted from the supplementary material of a previous study (Schwartz and Gygi, 2005), which contains 298 serine-phosphorylated peptides contains the following four kinds of kinases: Ataxia Telangiectasia Mutated (ATM, 43 peptides), Casein II (184 peptides), Calcium/Calmodulin-dependent protein Kinase II (CaMK II, 41 peptides), and Mitogen-Activated Protein Kinase (MAPK, 30 peptides).

Seq_positive_ALL_PKA_S_13_phosphoELM_1208.txt
The foreground data set contains all species with respect to PKA kinase substrates (322 serine-phosphorylated peptides)

Seq_positive_ALL_PKC_S_13_phosphoELM_1208.txt
The foreground data set contains all species with respect to PKC kinase substrates (333 serine-phosphorylated peptides)

Seq_positive_ALL_CDK_S_13_phosphoELM_1208.txt
The foreground data set contains all species with respect to CDK kinase substrates (213 serine-phosphorylated peptides)

Seq_positive_ALL_CK2_S_13_phosphoELM_1208.txt
The foreground data set contains all species with respect to CK2 kinase substrates (247 serine-phosphorylated peptides)

Seq_positive_ALL_4-Kinases_S_13_phosphoELM_1208.txt
The foreground data set contains all species with respect to PKA, PKC, CDK, and CK2 kinase substrates (1115 serine-phosphorylated peptides)

Seq_positive_Homo-sapiens_PKA_S_13_phosphoELM_1208.txt
The foreground data set contains only human species with respect to PKA kinase substrates (187 serine-phosphorylated peptides)

Seq_positive_Homo-sapiens_PKC_S_13_phosphoELM_1208.txt
The foreground data set contains only human species with respect to PKC kinase substrates (210 serine-phosphorylated peptides)

Seq_positive_Homo-sapiens_CDK_S_13_phosphoELM_1208.txt
The foreground data set contains only human species with respect to CDK kinase substrates (155 serine-phosphorylated peptides)

Seq_positive_Homo-sapiens_CK2_S_13_phosphoELM_1208.txt
The foreground data set contains only human species with respect to CK2 kinase substrates (177 serine-phosphorylated peptides)

Seq_positive_Homo-sapiens_4-Kinases_S_13_phosphoELM_1208.txt
The foreground data set contains only human species with respect to PKA, PKC, CDK, and CK2 kinase substrates (729 serine-phosphorylated peptides)

backgroundset:

ELM_1208_backgroundset_S_13.txt
All species background data set (414495 serine-phosphorylated and non-phosphorylated peptides)

ELM_1208_Homo-sapiens_backgroundset_S_13.txt
Human background data set (249175 serine-phosphorylated and non-phosphorylated peptides)