foregroundset:

nbt1146-S6.txt
This foreground data set is adopted from the supplementary material of a previous study (Schwartz and Gygi, 2005), which contains 298 serine-phosphorylated peptides considering the following four kinds of kinases: Ataxia Telangiectasia Mutated (ATM, 43 peptides), Casein II (184 peptides), Calcium/Calmodulin-dependent protein Kinase II (CaMK II, 41 peptides), and Mitogen-Activated Protein Kinase (MAPK, 30 peptides).

nbt1146-S5_s2.txt
This foreground data set is adopted from the supplementary material of a previous study (Schwartz and Gygi, 2005), which contains 3000 synthetic peptides with 814 peptides having five specially designed synthetic motifs "XXXDXXSQXNXXX", "XXXXRXSXXLXXX", "XXXTVXSXEXXXX", "XXXXRXSXXPXXX", and "XXXXXKSXXXIXX". 

Seq_positive_ALL_PKA_S_13_phosphoELM_1208.txt
The foreground data set considering all species with respect to PKA kinase substrates (306 serine-phosphorylated peptides)

Seq_positive_ALL_PKC_S_13_phosphoELM_1208.txt
The foreground data set contains all species with respect to PKC kinase substrates (297 serine-phosphorylated peptides)

Seq_positive_ALL_CDK_S_13_phosphoELM_1208.txt
The foreground data set contains all species with respect to CDK kinase substrates (209 serine-phosphorylated peptides)

Seq_positive_ALL_CK2_S_13_phosphoELM_1208.txt
The foreground data set contains all species with respect to CK2 kinase substrates (241 serine-phosphorylated peptides)

Seq_positive_ALL_4-Kinases_S_13_phosphoELM_1208.txt
The foreground data set contains all species with respect to PKA, PKC, CDK, and CK2 kinase substrates (998 serine-phosphorylated peptides)

Seq_positive_Homo-sapiens_PKA_S_13_phosphoELM_1208.txt
The foreground data set contains only human species with respect to PKA kinase substrates (187 serine-phosphorylated peptides)

Seq_positive_Homo-sapiens_PKC_S_13_phosphoELM_1208.txt
The foreground data set contains only human species with respect to PKC kinase substrates (209 serine-phosphorylated peptides)

Seq_positive_Homo-sapiens_CDK_S_13_phosphoELM_1208.txt
The foreground data set contains only human species with respect to CDK kinase substrates (155 serine-phosphorylated peptides)

Seq_positive_Homo-sapiens_CK2_S_13_phosphoELM_1208.txt
The foreground data set contains only human species with respect to CK2 kinase substrates (177 serine-phosphorylated peptides)

Seq_positive_Homo-sapiens_4-Kinases_S_13_phosphoELM_1208.txt
The foreground data set contains only human species with respect to PKA, PKC, CDK, and CK2 kinase substrates (697 serine-phosphorylated peptides)

pr800599n_11_S_N.txt
This foreground data set is adopted from the supplementary material of a previous study (Zanivan and et al., 2008), which is the mouse mass spectrometry data with 5174 mouse serine-phosphorylated sites under multiple TiO2 conditions.

backgroundset:

ELM_1208_backgroundset_S_13.txt
All species background data set (346248 serine-phosphorylated and non-phosphorylated peptides)

ELM_1208_Homo-sapiens_backgroundset_S_13.txt
Human background data set (233805 serine-phosphorylated and non-phosphorylated peptides)

ipi.MOUSE.v3.71.fasta_S_N_s.txt
Mouse background data set from the IPI mouse database (Totally, 1029584 peptides are assembled for this background data set, but half of them are randomly selected (514792 peptides), 


